const {Pool} = require('pg');

const pool= new Pool ({
    host: 'localhost',
    user: 'postgres',
    password: 'OliMen1205.',
    database: 'db_curso_app',
    port: '5432'
});

const getUsers = async (req, res) => {
   const response = await pool.query('SELECT * from persona');
   res.status(200).json(response.rows);
};

const createUsers = async (req, res) => {
    const {cedula, nombres, apellidos, fecha_nacimiento, telefono, direccion} = req.body;

    const response = await pool.query('INSERT INTO persona (cedula, nombres, apellidos, fecha_nacimiento, telefono, direccion) VALUES ($1, $2, $3, $4, $5, $6)',
    [cedula, nombres, apellidos, fecha_nacimiento, telefono, direccion]);
    console.log(response);
    res.json({
        message: 'Persona agregada correctamente',
        body: {
            persona: {cedula, nombres, apellidos, fecha_nacimiento, telefono, direccion}
        }
    })

};

const getUserById = async (req, res) => {
    const idpersona = req.params.idpersona;
    const response = await pool.query('SELECT * from persona WHERE idpersona = $1', [idpersona])
    res.json(response.rows);
};

const updateUser = async (req, res) => {
    const idpersona = req.params.idpersona;
    const {telefono, direccion} = req.body;
    const response = await pool.query('UPDATE persona SET telefono = $1, direccion = $2 WHERE idpersona = $3', [
        telefono, direccion, idpersona
    ]);
    console.log(response);
    res.json('Persona actualizada correctamente');

}

const deleteUser = async (req, res) => {
    const idpersona = req.params.idpersona;
    const response = await pool.query('DELETE from persona WHERE idpersona = $1', [idpersona]);
    console.log(response);
    res.json('Persona eliminada correctamente');
};

module.exports = {
    getUsers,
    createUsers,
    getUserById,
    deleteUser,
    updateUser
}