create database db_curso_app;

create table persona (
    idpersona serial primary key,
    cedula varchar (20),
    nombres varchar (50),
    apellidos varchar (50),
    fecha_nacimiento date,
    telefono varchar (50),
    direccion varchar (50)
    );

INSERT INTO persona (cedula, nombres, apellidos, fecha_nacimiento, telefono, direccion) VALUES
('1298554098', 'Juan Antonio','Laz Véliz', '1999-01-22', '091289004', 'Calle 133'),
('1314560932', 'Sasha Antonella', 'Sabando Paz', '1997-08-11', '0909456387', 'Callle principal Jesús Cordero'),
('1709836589', 'Dayana Cristhina', 'García Núñez', '2002-10-07', '0998127635', 'Avenida Montesdeoca'),
('1509584724', 'Paulo Samuel', 'Zambrano Mendoza', '2000-05-30', '0909873408', 'Avenida Puerto Real');

