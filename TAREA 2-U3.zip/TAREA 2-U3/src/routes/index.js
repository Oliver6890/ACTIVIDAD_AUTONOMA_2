const {Router} = require('express');
const router = Router();

const {getUsers, createUsers, getUserById, deleteUser, updateUser} = require('../controllers/index.controller')

router.get('/users', getUsers);
router.post('/users', createUsers);
router.get('/users/:idpersona', getUserById);
router.delete('/users/:idpersona', deleteUser);
router.put('/users/:idpersona', updateUser);

module.exports = router;